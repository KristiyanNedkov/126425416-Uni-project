#include <cs50.h>
#include <stdio.h>
#include <string.h>

#define MAX_EMPLOYEES 100

typedef struct
{
    int id;
    string name;
    float basic_salary;
    float income_tax_rate;
    float pension_rate;
    float health_rate;
    float net_salary;
}
Employee;

Employee employees[MAX_EMPLOYEES];
int count = 0;


/**//**//**//**//**//**//**//**/
//prototypes
/**//**//**//**//**//**//**//**/
void add_employee(void);
void display_employees(void);
void calculate_salary(void);

int main(void)
{
    int choice;

    do
    {
        printf("\n==================================\n");
        printf("   PAYROLL MANAGEMENT SYSTEM\n");
        printf("==================================\n");
        printf("1. Add Employee\n");
        printf("2. Display All Employees\n");
        printf("3. Calculate Net Salaries\n");
        printf("4. Exit\n");
        printf("==================================\n");

        choice = get_int("Enter your choice: ");

        switch (choice)
        {
            case 1:
            add_employee();
            break;

            case 2:
            display_employees();
            break;

            case 3:
            calculate_salary();
            break;

            case 4:
            printf("Exiting program...\n");
            break;

            default:
            printf("Invalid choice!\n");
        }
    }
    while (choice != 4);

    return 0;
}

/**//**//**//**//**//**//**//**//**/
//definitions
/**//**//**//**//**//**//**//**//**/
void add_employee(void)
{
    if (count >= MAX_EMPLOYEES)
    {
        printf("Employee limit reached!\n");
        return;
    }

    printf("\n--- Add New Employee ---\n");
    employees[count].id = get_int("Enter ID: ");
    employees[count].name = get_string("Enter name: ");
    employees[count].basic_salary = get_float("Enter basic salary: ");

    //default tax rates
    employees[count].income_tax_rate = 0.10;   //10%
    employees[count].pension_rate = 0.08;      //8%
    employees[count].health_rate = 0.04;       //4%

    employees[count].net_salary = 0.0; 

    count++;
    printf("Employee added successfully!\n");
}

void display_employees(void)
{
    if (count == 0)
    {
        printf("No employees to display.\n");
        return;
    }

    printf("\n-----------------------------------------------------------------\n");
    printf("%-10s %-20s %-15s %-15s\n",
           "ID", "Name", "Basic Salary", "Net Salary");
    printf("-----------------------------------------------------------------\n");

    for (int i = 0; i < count; i++)
    {
        printf("%-10d %-20s %-15.2f %-15.2f\n",
               employees[i].id,
               employees[i].name,
               employees[i].basic_salary,
               employees[i].net_salary);
    }

    printf("-----------------------------------------------------------------\n");
}

void calculate_salary(void)
{
    if (count == 0)
    {
        printf("No employees available.\n");
        return;
    }

    for (int i = 0; i < count; i++)
    {
        float income_tax = employees[i].basic_salary * employees[i].income_tax_rate;
        float pension = employees[i].basic_salary * employees[i].pension_rate;
        float health = employees[i].basic_salary * employees[i].health_rate;

        employees[i].net_salary = employees[i].basic_salary - income_tax - pension - health;
    }

    printf("Net salaries calculated successfully!\n");
}
